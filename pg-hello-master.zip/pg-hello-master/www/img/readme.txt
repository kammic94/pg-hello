Image files... eg. icons, splashscreen
